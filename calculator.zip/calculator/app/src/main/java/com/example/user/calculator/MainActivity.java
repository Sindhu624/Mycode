package com.example.user.calculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText op1,op2;
TextView ans;
Button add,sub,mul,div;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        add=(Button)findViewById(R.id.button);
        sub=(Button)findViewById(R.id.button2);
        mul=(Button)findViewById(R.id.button3);
        div=(Button)findViewById(R.id.button4);
        op1=(EditText)findViewById(R.id.editText);
        op2=(EditText)findViewById(R.id.editText2);
        ans=(TextView)findViewById(R.id.textView);
        add.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display1();
                ans.setText(Integer.toString(answer));
            }
        });
        sub.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display2();
                ans.setText(Integer.toString(answer));
            }
        });
        mul.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display3();
                ans.setText(Integer.toString(answer));
            }
        });
        div.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display4();
                ans.setText(Integer.toString(answer));

            }
        });


    }
    public Integer get_nd_display1()
    {
        String one=op1.getText().toString();
        String two=op2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a+b;
        return c;
    }
    public Integer get_nd_display2()
    {
        String one=op1.getText().toString();
        String two=op2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int d=a-b;
        return d;

    }
    public  Integer get_nd_display3()
    {
        String one=op1.getText().toString();
        String two=op2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int e=a*b;
        return e;
    }
    public  Integer get_nd_display4()
    {
        String one=op1.getText().toString();
        String two=op2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int f=0;
        try
        {
            f=a/b;

        }
        catch(Exception e)
        {
            Toast.makeText(MainActivity.this,"cannot divide by zero",Toast.LENGTH_LONG).show();
        }
        return f;

    }



}

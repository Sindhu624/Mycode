package com.example.user.widgets;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
ToggleButton tg1;
CheckBox ch1;
RadioButton m1,f1;
TextView t1,t2,t3,t4;
SeekBar sk1;
Switch sw;
ImageView iv1;
RelativeLayout lay;
RadioGroup rg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tg1=(ToggleButton)findViewById(R.id.toggleButton);
        ch1=(CheckBox)findViewById(R.id.checkBox);
        m1=(RadioButton)findViewById(R.id.radioButton);
        f1=(RadioButton)findViewById(R.id.radioButton2);
        sk1=(SeekBar)findViewById(R.id.seekBar2);
        sw=(Switch)findViewById(R.id.switch2);
        iv1=(ImageView)findViewById(R.id.imageView2);
        t1=(TextView)findViewById(R.id.textView);
        t2=(TextView)findViewById(R.id.textView2);
        t3=(TextView)findViewById(R.id.textView3);
        t4=(TextView)findViewById(R.id.textView4);
        lay= (RelativeLayout)findViewById(R.id.rlayout);
        rg=(RadioGroup)findViewById(R.id.radgrp);

        //toggle function
        tg1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    // if toggle button is enabled/on
                    lay.setBackgroundResource(R.drawable.layout);

                    // Make a toast to display toggle button status
                    Toast.makeText(getApplicationContext(),
                            "Toggle is on", Toast.LENGTH_SHORT).show();
                    t1.setText("nightmode on");
                }
                else{
                    // If toggle button is disabled/off
                    lay.setBackgroundResource(android.R.drawable.btn_default);

                    // Make a toast to display toggle button status
                    Toast.makeText(getApplicationContext(),
                            "Toggle is off", Toast.LENGTH_SHORT).show();
                    t1.setText("nightmode off");
                }
            }
        });

        //checkbox function
        ch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked)
                {
                        t2.setText("checkbox selected");
                }
                else
                {

                        t2.setText("checkbox disabled");
                }
                }

            });

        //radiobox function



        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                View radioButton = rg.findViewById(checkedId);
                int index = rg.indexOfChild(radioButton);

                // Add logic here

                switch (index) {
                    case 0: // first button

                        Toast.makeText(getApplicationContext(), "male" ,Toast.LENGTH_SHORT).show();
                        t3.setText("male");
                        break;
                    case 1: // secondbutton
                        t3.setText("female");
                        Toast.makeText(getApplicationContext(), "female ",Toast.LENGTH_LONG).show();
                        break;
                }
            }
        });

        //seekbar function
        sk1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                t4.setTextSize(progress);
                ///Toast.makeText(getApplicationContext(), String.valueOf(progress),Toast.LENGTH_LONG).show();

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //swtch function
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                iv1= (ImageView) findViewById(R.id.imageView2);
                Animation startRotateAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                if(isChecked)
                {
                    iv1.startAnimation(startRotateAnimation);
                    //startRotateAnimation.
                }
                else
                {
                    iv1.clearAnimation();
                }

                }
        });



}
}





























